package com.example.AIII

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
