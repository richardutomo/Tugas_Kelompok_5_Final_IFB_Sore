import 'dart:convert';
import 'dart:io';

import 'package:alan_voice/alan_voice.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class Company{
  String companyname;
  String usinguser;
  String key;
  List user;
  List product;
  int salescode;
  List sales;
  int purchasecode;
  List purchase;

  Company({
    required this.companyname, 
    required this.usinguser, 
    required this.key, 
    required this.user, 
    required this.product, 
    required this.salescode, 
    required this.sales, 
    required this.purchasecode,
    required this.purchase
  });
}

class ProviderGudang extends ChangeNotifier{
  Company Gudang = Company(
    companyname: "Normal Store", 
    usinguser: "",
    key: "hello", 
    user: [
      ["OWNER","SELLER","PURCHASER"],
      ["111","123","456"],
       [
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIgp6aJcoa9_mornRyWV1vDfEVlkN9mPImV4x-uz1XYQ&s",
        "https://i.pinimg.com/736x/da/4a/fa/da4afa2d21a74a4f829f86971e826b69.jpg",
        "https://i.pinimg.com/736x/54/72/d1/5472d1b09d3d724228109d381d617326.jpg"
      ]
    ], 
    product: [
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r992-lsct022cl52179'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Red Plastic Hanger","EKL",230],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98r-lsct022cibx568'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Small Plastic Hanger","EKL",230],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r992-lsct022cjqhl13'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Green Plastic Bucket","EKL",250],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98v-lsct022cgxmu09'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Small Plastic Basin","EKL",300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r990-lsct022cny6xe5'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Big Plastic Basin","EKL",300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98y-lthnk07b51xe03'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Premium Quality PVC Faucet","OllO",200],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98u-lt7kukaiu8ue77'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Premium Quality Raskam","EKL",220],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98z-lti1e8325da029'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Rotary Water Faucet","OllO",250],
    ], 
    salescode: 3,
    sales: [
      ["S001","05-03-2024","Winny","SELLER",
      [[Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r992-lsct022cl52179'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Red Plastic Hanger",22000,70],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r992-lsct022cjqhl13'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Green Plastic Bucket",15000,50]],
      2290000],
      ["S002","10-03-2024","Andy","PURCHASER",
      [[Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98z-lti1e8325da029'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Rotary Water Faucet",30000,50],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98u-lt7kukaiu8ue77'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Premium Quality PVC Faucet",30000,100]],
      4500000],
      ["S003","20-03-2024","City","OWNER",
      [[Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98u-lt7kukaiu8ue77'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Premium Quality Raskam",60000,80],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98r-lsct022cibx568'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Small Plastic Hanger",18000,70],],
      6060000],
    ], 
    purchasecode: 3,
    purchase: [
      ["P001","05-03-2024","West","OWNER",
      [[Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r992-lsct022cl52179'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Red Plastic Hanger",15000,300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r992-lsct022cjqhl13'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Green Plastic Bucket",15000,300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98r-lsct022cibx568'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Small Plastic Hanger",12000,300]],
      12600000],
      ["P002","09-03-2024","Tenny","OWNER",
      [[Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98v-lsct022cgxmu09'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Small Plastic Basin",30000,300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98u-lt7kukaiu8ue77'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Premium Quality Raskam",35000,300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r990-lsct022cny6xe5'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Big Plastic Basin",45000,300]],
      33000000],
      ["P003","11-03-2024","Tail","PURCHASER",
      [[Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98u-lt7kukaiu8ue77'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Premium Quality PVC Faucet",25000,300],
      [Image(
        image: NetworkImage('https://down-id.img.susercontent.com/file/id-11134207-7r98z-lti1e8325da029'),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      ),"Rotary Water Faucet",25000,300]],
      15000000]
    ],
  );

  void updateDataStock(int index, Widget? newData){
    Gudang.product[index][0] = newData;
    notifyListeners();
  }

  void addStock(BuildContext context, List item, int? valimg) {
    if (item[1] == "" || item[2] == "" || (item[3] == 2 && item[4] == "") || (item[0]==null || item[0]=="")) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Alert'),
            content: Text('Data Cannot Empty'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
    else if(newList(Gudang.product).contains(item[1])){
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Alert'),
            content: Text('Product Name already Exist'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
    }
    else{
      Widget gmbr = valimg==0
      ? Image(
        image: FileImage(File(item[0]!.path)),
        height: 90,
        width: 90,
        fit: BoxFit.contain,
      )
      : Image(
        image: NetworkImage(item[0]),
        height: 90,
        width: 90,
      );
      List result = [gmbr, item[1], item[2], item[3]==2 ? int.parse(item[4]) : 0];
      Gudang.product.add(result);
      Navigator.of(context).pop(true);
    }
    notifyListeners();
  }

  void addAccount(String x, String y) {
    Gudang.user[0].add(x);
    Gudang.user[1].add(y);
    notifyListeners();
  }

  void addPurchase(List x) {
    Gudang.purchase.add(x);
    notifyListeners();
  }

  void addSales(List x) {
    Gudang.sales.add(x);
    notifyListeners();
  }

  void sendUserInfo () async {
    var isAvtive = await AlanVoice.isActive();
    if(!isAvtive) {
      AlanVoice.activate();
    }
    var params = jsonEncode({"user": Gudang.usinguser});
    AlanVoice.callProjectApi("script::getUserinfo", params);
    notifyListeners();
  }

  
  void changeVisual (String name) {
    String visual = "{\"screen\":\"${name}\"}";
    AlanVoice.setVisualState(visual);
    print(visual);
  }
}

class TransactionModel extends ChangeNotifier{
  List <dynamic> ordered = [];
  bool isedit = false;

  void addordered(List order) {
    ordered.add(order);
    notifyListeners();
  }

  void removeordered(List item) {
    ordered.remove(item);
    notifyListeners();
  }

  void editordered(int index,List order) {
    ordered[index] = order;
    notifyListeners();
  }

  void changeedit(bool cek) {
    isedit = cek;
    notifyListeners();
  }

}

class SearchModel extends ChangeNotifier{
  List filter = ProviderGudang().Gudang.product;
  List filterpurchasing = ProviderGudang().Gudang.purchase;
  List filtersales = ProviderGudang().Gudang.sales;
  TextEditingController search = TextEditingController();
  TextEditingController searchsales = TextEditingController();
  TextEditingController searchpurchasing = TextEditingController();

  void change(List filtered) {
    filter = filtered;
    notifyListeners();
  }

  void changesales(List filtered) {
    filtersales = filtered;
    notifyListeners();
  }

  void changepurchasing(List filtered) {
    filterpurchasing = filtered;
    notifyListeners();
  }

  void updateSearchSales(String word) {
    searchsales.text = word;
    notifyListeners();
  }

  void updateSearchPurchasing(String word) {
    searchpurchasing.text = word;
    notifyListeners();
  }

  void updateSearch(String word) {
    search.text = word;
    notifyListeners();
  }

}

class ProductImageModel extends ChangeNotifier {
  XFile? imageEdit = null;
  int? dvalimg = 0;
  Widget? dgambar = null;
  bool editing = false;
  int index = -1;

  void updatedvalimg (int x) {
    dvalimg = x;
    notifyListeners();
  }

  void updateimage (XFile? x) {
    imageEdit = x;
    notifyListeners();
  }

  void updatedgambar (Widget? x) {
    dgambar = x;
    notifyListeners();
  }

  void updateediting(bool x) {
    editing = x;
  }
}

class NewProductImageModel extends ChangeNotifier {
  XFile? image = null;
  int? valimg = 0;
  int? valstock = 1;
  bool showlinkimg = false;

  void changeshowlinkimg(bool x){
    showlinkimg = x;
    notifyListeners();
  }

  void changevalstock(int? val){
    valstock = val;
    notifyListeners();
  }

  void updateimage(XFile? img){
    image = img;
    notifyListeners();
  }

  void changevalimg(int? value){
    valimg = value;
    notifyListeners();
  }
}

List<dynamic> listfitur = [[
    Icons.attach_money,
    Icons.sell,
    Icons.warehouse,
    Icons.info
  ],[
    "Purchasing","Sales","Stock","About"
  ]];

  List<dynamic> newList(List<dynamic> inputList) {
    List hasil = [];
    inputList.forEach((subList) {
      hasil.add(subList[1]);
    });
    return hasil;
  }

void sendsaveimg () async {
  var isAvtive = await AlanVoice.isActive();
  if(!isAvtive) {
    AlanVoice.activate();
  }
  var params = jsonEncode({"status": true});
  AlanVoice.callProjectApi("script::imgnewproduct", params);
}
