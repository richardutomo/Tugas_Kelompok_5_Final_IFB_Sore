import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:AIII/AboutPage.dart';
import 'package:AIII/AccountView.dart';
import 'package:AIII/AddStockPage.dart';
import 'package:AIII/AddTransactionPage.dart';
import 'package:AIII/ProductDetail.dart';
import 'package:AIII/ProfilePage.dart';
import 'package:AIII/PurchasingPage.dart';
import 'package:AIII/RegisterPage.dart';
import 'package:AIII/SalesPage.dart';
import 'package:AIII/StockPage.dart';
import 'package:alan_voice/alan_voice.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:AIII/component/data.dart';
import 'package:AIII/HomePage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class LoginView extends StatefulWidget {
  
  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  TextEditingController user = TextEditingController();
  TextEditingController pass = TextEditingController();
  bool isCocok = true;
  bool isVisible = false;

  _LoginViewState() {
  /// Init Alan Button with project key from Alan AI Studio      
  AlanVoice.addButton("1d6853fd9b8ae134868d597ac893ce5a2e956eca572e1d8b807a3e2338fdd0dc/stage",
  buttonAlign: AlanVoice.BUTTON_ALIGN_LEFT);

  /// Handle commands from Alan AI Studio
  AlanVoice.onCommand.add(
    (command) => _handleCommand(command.data)
  );
}

  void _handleCommand(Map<String, dynamic> command) {
    ProductImageModel prov = Provider.of<ProductImageModel>(context,listen: false);
    NewProductImageModel newprov = Provider.of<NewProductImageModel>(context,listen: false);
    datastock = Provider.of<ProviderGudang>(context,listen: false).Gudang.product;
    datasales = Provider.of<ProviderGudang>(context,listen: false).Gudang.sales;
    datapurchasing = Provider.of<ProviderGudang>(context,listen: false).Gudang.purchase;
    Company data = Provider.of<ProviderGudang>(context,listen: false).Gudang;
    switch(command["command"]) {
      case "Open profile":
        Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Home");
        });});
        break;
      case "Open sales":
        Navigator.push(context, MaterialPageRoute(builder: (context) => SalesView(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Home");
        });});
        break;
      case "Open purchasing":
        Navigator.push(context, MaterialPageRoute(builder: (context) => PurchasingView(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Home");
        });});
        break;
      case "Open about":
        Navigator.push(context, MaterialPageRoute(builder: (context) => AboutView(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Home");
        });});
        break;
      case "Open stock":
        Navigator.push(context, MaterialPageRoute(builder: (context) => StockView(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Home");
        });});
        break;
      case "Add Product":
        Navigator.push(context, MaterialPageRoute(builder: (context) => AddStock(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Stock");
        });});
        break;
      case "inputLink":
        link.text = command['text'];
        break;
      case "inputPName":
        newstockname.text = command['text'];
        break;
      case "inputBrand":
        brand.text = command['text'];
        break;
      case "inputstock":
        stock.text = command['text'];
        break;
      case "oldstock":
        Provider.of<NewProductImageModel>(context,listen: false).changevalstock(2);
      case "insertnewproduct":
        if (Provider.of<ProviderGudang>(context,listen: false).Gudang.product.contains(newstockname.text)) {
          var params = jsonEncode({"status": [false]});
          AlanVoice.callProjectApi("script::getstatusaddstock", params);
        }
        else{
          List item = newprov.valimg==0 
          ? [newprov.image, newstockname.text, brand.text, newprov.valstock, newprov.valstock==2 ? stock.text : 0] 
          : [link.text, newstockname.text, brand.text, newprov.valstock, newprov.valstock==2 ? stock.text : 0];
          Provider.of<ProviderGudang>(context,listen: false).addStock(context, item, newprov.valimg);                        
          var params = jsonEncode({"status": [true]});
          AlanVoice.callProjectApi("script::getstatusaddstock", params);
        }
        Provider.of<SearchModel>(context,listen: false).change(Provider.of<ProviderGudang>(context,listen: false).Gudang.product);
        break;
      case "Open account list":
        Navigator.push(context, MaterialPageRoute(builder: (context) => AccountView(),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Home");
        });});
        break;
      case "Open Register":
        Navigator.push(context, MaterialPageRoute(builder: (context) => RegistrationView(),));
        break;
      case "Logout" :
        Navigator.popUntil(context, (route) => route.isFirst);
        Provider.of<ProviderGudang>(context,listen: false).Gudang.usinguser == "";
        Provider.of<ProviderGudang>(context,listen: false).changeVisual("Login");
        break;
      case "Go Back" : 
        Navigator.of(context).pop();
        break;
      case "getRName" : 
        setState(() {
          ruser.text = command["text"];
        });
        break;
      case "getRPass" :
        setState(() {
          rpass.text = command["text"];
        });
        break;
      case "getRCPass":
        setState(() {
          rconfirm.text = rpass.text;
        });
        break;
      case "getKey":
        setState(() {
          rkunci.text = command['text'];
        });
        break;
      case "Register Action":
        if (rkunci.text == data.key){
          setState(() {
            if (data.user[0].contains(ruser.text.toUpperCase())){
              risSame = true;
              risKey = true;
              var params = jsonEncode({"status": [false,ruser.text.toUpperCase()]});
              AlanVoice.callProjectApi("script::getStatusRegister", params);
            }
            else{
              risKey = true;
              risPass = true;
              data.user[0].add(ruser.text.toUpperCase());
              data.user[1].add(rpass.text);
              data.user[2].add("https://static.vecteezy.com/system/resources/thumbnails/009/292/244/small/default-avatar-icon-of-social-media-user-vector.jpg");
              Navigator.of(context).pop();
              Provider.of<ProviderGudang>(context,listen: false).changeVisual("Login");
              var params = jsonEncode({"status": [true,ruser.text.toUpperCase()]});
              AlanVoice.callProjectApi("script::getStatusRegister", params);
              ruser.clear();
              rpass.clear();
              rkunci.clear();
              rconfirm.clear();
            }
          });
        }
        else{
          setState(() {
            var params = jsonEncode({"status": [true,ruser.text.toUpperCase()]});
            AlanVoice.callProjectApi("script::getStatusRegister", params);
            risKey = false;
            ruser.clear();
            rpass.clear();
            rkunci.clear();
            rconfirm.clear();
          });
        }
        break;
      case "getName" : 
        user.text = command["text"];
        break;
      case "getPass" : 
        pass.text = command["text"];
        setState(() {
          List account = Provider.of<ProviderGudang>(context,listen: false).Gudang.user;
          int index = account[0].indexOf(user.text.toUpperCase());
          if (index != -1 && account[1][index] == pass.text) {
            Provider.of<ProviderGudang>(context, listen: false).Gudang.usinguser = account[0][index];
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => HomeView(
                  data: Provider.of<ProviderGudang>(context).Gudang,
                  fitur: listfitur,
                  user: Provider.of<ProviderGudang>(context).Gudang.usinguser
                )
              )
            ).then((value) {
              Provider.of<ProviderGudang>(context,listen: false).changeVisual("Login");
            });
            var params = jsonEncode({"status": [true,user.text.toUpperCase()]});
            AlanVoice.callProjectApi("script::getStatusLogin", params);
            user.clear();
            pass.clear();
          } else {
            var params = jsonEncode({"status": [false,user.text.toUpperCase()]});
            AlanVoice.callProjectApi("script::getStatusLogin", params);
            isCocok = false;
            user.clear();
            pass.clear();
          }
        });
        break;
      case "getSearchStock" : 
        setState(() {
          Provider.of<SearchModel>(context,listen: false).updateSearch(command['text']);
          List filtered = [];
          List result = [];
          for (int i = 0;i < datastock.length; i++) {
            if (datastock[i][1].toLowerCase().contains(command["text"].toLowerCase()) || datastock[i][2].toLowerCase().contains(command['text'].toLowerCase())) {
              filtered.add(datastock[i]);
              List format = [datastock[i][1],datastock[i][2],datastock[i][3]];
              result.add(format);
            }
          }
          Provider.of<SearchModel>(context,listen: false).change(filtered);
          var params = jsonEncode({"result": result});
          AlanVoice.callProjectApi("script::getSearchResult", params);
        });
        break;
      case "getSearchSales" : 
        setState(() {
          Provider.of<SearchModel>(context,listen: false).updateSearchSales(command['text']);
          List filtered = [];
          for (int i = 0;i < datasales.length; i++) {
            if (datasales[i][0].toLowerCase().contains(command['text'].toLowerCase()) || datasales[i][2].toLowerCase().contains(command['text'].toLowerCase()) || datasales[i][3].toLowerCase().contains(command['text'].toLowerCase())) {
              filtered.add(datasales[i]);
            }
          }
          Provider.of<SearchModel>(context,listen: false).changesales(filtered);
        });
        break;
      case "Add sales":
        Navigator.push(context, MaterialPageRoute(builder: (context) => AddTransaction(type: command['text'],),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual(command['text']);
        });});
        break;
      case "insertitemorder":
        product = [];
        item.text = command['item'];
        for (var i = 0; i<semuaItem.length ; i++) {
          if(semuaItem[i][1].toLowerCase() == command['item'].toLowerCase()){
            product = semuaItem[i];
          } 
        }
        break;
      case "insertqtyorder":
        qty.text = command['qty'];
        break;
      case "insertpriceorder":
        price.text = command['price'];
        break;
      case "inserttolistorder":
        if (product.isEmpty) {
          var params = jsonEncode({"result": false});
          AlanVoice.callProjectApi("script::getaddproresult", params);
        }
        else if (price.text=="" || qty.text=="" || item.text=="") {
          var params = jsonEncode({"status": "Please fill the data before add"});
          AlanVoice.callProjectApi("script::sendtext", params);
        }
        else{
          List ordered = Provider.of<TransactionModel>(context,listen: false).ordered;
          List <dynamic> x = [product[0],product[1].toString(),int.parse(price.text),int.parse(qty.text)];
          Provider.of<TransactionModel>(context,listen: false).addordered(x);
          total = 0;
          for (int x = 0 ; x<ordered.length ; x++ ) {
            int jumlah = ordered[x][2]*ordered[x][3];
            total+=jumlah;
          }
          var params = jsonEncode({"result": true});
          AlanVoice.callProjectApi("script::getaddproresult", params);
        }
          item.text = "";
          price.text = "";
          qty.text = "";
          product = [];
          Provider.of<TransactionModel>(context,listen: false).changeedit(false);
        break;
      case "inserttransaction":
        List ordered = Provider.of<TransactionModel>(context,listen: false).ordered;
        if (tname.text.trim()=="") {
          var params = jsonEncode({"status": [false,"Please input customer before save"]});
          AlanVoice.callProjectApi("script::gettransactionResult", params);
        }
        else if (ordered.length==0) {
          var params = jsonEncode({"status": [false,"Please input product before save"]});
          AlanVoice.callProjectApi("script::gettransactionResult", params);
        }
        else{
          String numb = jenis == "Sales" ? (Provider.of<ProviderGudang>(context,listen: false).Gudang.salescode+1).toString().padLeft(3,"0") : (Provider.of<ProviderGudang>(context,listen: false).Gudang.purchasecode+1).toString().padLeft(3,"0");
          List alltransaction = jenis == "Sales"
          ? Provider.of<ProviderGudang>(context,listen: false).Gudang.sales
          : Provider.of<ProviderGudang>(context,listen: false).Gudang.purchase;
          jenis == "Sales" ? Provider.of<ProviderGudang>(context,listen: false).Gudang.salescode+=1 : Provider.of<ProviderGudang>(context,listen: false).Gudang.purchasecode+=1;
          String code = jenis == "Sales" ? "S" : "P";
          String user = Provider.of<ProviderGudang>(context,listen: false).Gudang.usinguser;
          List alldata = ["${code+numb}",DateFormat("dd-MM-yyyy").format(date),tname.text,user,ordered,total];
          jenis == "Sales" ? Provider.of<ProviderGudang>(context,listen: false).addSales(alldata) : Provider.of<ProviderGudang>(context,listen: false).addPurchase(alldata);
          List data = Provider.of<ProviderGudang>(context, listen: false).Gudang.product;
          for (int i = 0 ; i<ordered.length ; i++) {
            for (int j = 0 ; j<data.length ; j++) {
              if (data[j].contains(ordered[i][1])) {
                jenis == "Sales" ? data[j][3] = data[j][3]-ordered[i][3] : data[j][3] = data[j][3]+ordered[i][3];
              }
            }
          }
          jenis == "Sales" 
          ? Provider.of<SearchModel>(context,listen: false).changesales(alltransaction)
          : Provider.of<SearchModel>(context,listen: false).changepurchasing(alltransaction);
          
          var params = jsonEncode({"status": [true,"Success"]});
          AlanVoice.callProjectApi("script::gettransactionResult", params);
          Navigator.of(context).pop(true);
          }
        break;
      case "clearorder":
        item.clear();
        price.clear();
        qty.clear();
        Provider.of<TransactionModel>(context,listen: false).changeedit(false);
        break;
      case "findeditorder":
        List ordered = Provider.of<TransactionModel>(context,listen: false).ordered;
        List brg = [];
        for (var i = 0 ; i<ordered.length ; i++){
          if (ordered[i][1].toLowerCase() == command['text'].toLowerCase()) {
            brg = ordered[i];
            tindex=i;
          }
        }        
        if (brg.isEmpty) {
          var params = jsonEncode({"status": [false,"product name not found in list"]});
          AlanVoice.callProjectApi("script::geteditproresult", params);
        }
        else{
          item.text = brg[1];
          product = brg;
          price.text = "${brg[2]}";
          qty.text = "${brg[3]}";
          Provider.of<TransactionModel>(context,listen: false).changeedit(true);
          var params = jsonEncode({"status": [true,""]});
          AlanVoice.callProjectApi("script::geteditproresult", params);
        }
        break;
      case "finddeleteorder":
        List ordered = Provider.of<TransactionModel>(context,listen: false).ordered;
        List brg = [];
        for (var i = 0 ; i<ordered.length ; i++){
          if (ordered[i][1].toLowerCase() == command['text'].toLowerCase()) {
            brg = ordered[i];
          }
        }        
        if (brg.isEmpty) {
          var params = jsonEncode({"status": [false,"product name not found in list"]});
          AlanVoice.callProjectApi("script::getdeleteproresult", params);
        }
        else{
          Provider.of<TransactionModel>(context,listen: false).removeordered(brg);   
          total = 0;
          for (int x = 0 ; x<ordered.length ; x++ ) {
            int jumlah = ordered[x][2]*ordered[x][3];
            total+=jumlah;
          }       
          var params = jsonEncode({"status": [true,brg[1]]});
          AlanVoice.callProjectApi("script::getdeleteproresult", params);
        }
        break;
      case "editorder":
      if (product.isEmpty) {
        var params = jsonEncode({"status": "sorry, the product name not found, please choose another product"});
        AlanVoice.callProjectApi("script::sendtext", params);
      }
      else{
        List ordered = Provider.of<TransactionModel>(context,listen: false).ordered;
        List <dynamic> x = [product[0],product[1].toString(),int.parse(price.text),int.parse(qty.text)];
        Provider.of<TransactionModel>(context,listen: false).editordered(tindex, x);
        total = 0;
        for (int x = 0 ; x<ordered.length ; x++ ) {
          int jumlah = ordered[x][2]*ordered[x][3];
          total+=jumlah;
        }
        Provider.of<TransactionModel>(context,listen: false).changeedit(false);
        var params = jsonEncode({"status": "The product seccessfully edited"});
        AlanVoice.callProjectApi("script::sendtext", params);
        price.text = "";
        qty.text = "";
      }
      item.text = "";
      product = [];
        break;
      case "Add purchase":
        Navigator.push(context, MaterialPageRoute(builder: (context) => AddTransaction(type: command['text'],),)).then((value) {setState(() {
          Provider.of<ProviderGudang>(context,listen: false).changeVisual(command['text']);
        });});
        break;
      case "insertname":
        tname.text = command['text'];
        break;
      case "openProductInfo":
        String namaItem = command['text'];
        List allproduct = Provider.of<ProviderGudang>(context,listen: false).Gudang.product;
        for (int i = 0 ; i<allproduct.length ; i++) {
          if(allproduct[i][1].toLowerCase() == namaItem.toLowerCase()) {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (context) => InfoProduct(data: allproduct[i]))
            ).then((value) {setState(() {
              Provider.of<ProviderGudang>(context,listen: false).changeVisual("Stock");
            });});
            break;
          }
          else if (i==allproduct.length - 1 && allproduct[i][1] != namaItem){
            var params = jsonEncode({"status": "Sorry, Product not found"});
            AlanVoice.callProjectApi("script::sendtext", params);
          }
        }
        break;
      case "getSearchPurchasing" : 
        setState(() {
          Provider.of<SearchModel>(context,listen: false).updateSearchPurchasing(command['text']);
          List filtered = [];
          for (int i = 0;i < datapurchasing.length; i++) {
            if (datapurchasing[i][0].toLowerCase().contains(command['text'].toLowerCase()) || datapurchasing[i][2].toLowerCase().contains(command['text'].toLowerCase()) || datapurchasing[i][3].toLowerCase().contains(command['text'].toLowerCase())) {
              filtered.add(datapurchasing[i]);
            }
          }
          Provider.of<SearchModel>(context,listen: false).changepurchasing(filtered);
        });
        break;
      case "changeProductImageCamera" : 
        ProductImageModel prov = Provider.of<ProductImageModel>(context,listen: false);
        () async {
          prov.updatedvalimg(0);
          final XFile? image = await dpicker.pickImage(source: ImageSource.camera);
          setState(() {
            if (image != null) {
              prov.updateimage(image);
              prov.updatedgambar(Image(
                image: FileImage(File(prov.imageEdit!.path)),
                height: 90,
                width: 90,
                fit: BoxFit.contain,
              ));
              prov.updateediting(true);
              var params = jsonEncode({"status": true});
              AlanVoice.callProjectApi("script::detailimageconfirmation", params);
            }
            else{
              var params = jsonEncode({"status": false});
              AlanVoice.callProjectApi("script::detailimageconfirmation", params);
            }
          });
        }();
        break;
      case "changeProductImageGallery" : 
        () async {
          prov.updatedvalimg(0);
          final XFile? image = await dpicker.pickImage(source: ImageSource.gallery);
          setState(() {
            if(image!=null) {
              prov.updateimage(image);
              prov.updatedgambar(Image(
                image: FileImage(File(prov.imageEdit!.path)),
                height: 90,
                width: 90,
                fit: BoxFit.contain,
              ));
              prov.updateediting(true);
              var params = jsonEncode({"status": true});
              AlanVoice.callProjectApi("script::detailimageconfirmation", params);
            }
            else{
              var params = jsonEncode({"status": false});
              AlanVoice.callProjectApi("script::detailimageconfirmation", params);
            }
          });
        }();
        break;
      case "changeProductImageLink" : 
          setState(() {
            prov.updatedvalimg(1);
          });
        break;
      case "saveproductimage":
        Widget? newData = prov.dgambar;
        Provider.of<ProviderGudang>(context,listen: false).updateDataStock(prov.index, newData);
        prov.updateediting(!prov.editing);
        break;
      case "cancelproductimage":
        prov.updateediting(!prov.editing);
        prov.updatedgambar(null);
        break;
      case "newimagecamera":
        () async {
          newprov.changevalimg(0);
          final XFile? image = await dpicker.pickImage(source: ImageSource.camera);
          setState(() {
            if(image!=null){
              newprov.updateimage(image);
              newprov.changevalimg(0);
              var params = jsonEncode({"status": true});
              AlanVoice.callProjectApi("script::imgnewproduct", params);
            }
            else{
              var params = jsonEncode({"status": false});
              AlanVoice.callProjectApi("script::imgnewproduct", params);
            }
          });
        }();
        break;
      case "newimagegallery":
        () async {
          newprov.changevalimg(0);
          final XFile? image = await dpicker.pickImage(source: ImageSource.gallery);
          setState(() {
            if(image!=null){
              newprov.updateimage(image);
              newprov.changevalimg(0);
              var params = jsonEncode({"status": true});
              AlanVoice.callProjectApi("script::imgnewproduct", params);
            }
            else{
              var params = jsonEncode({"status": false});
              AlanVoice.callProjectApi("script::imgnewproduct", params);
            }
          });
        }();
        break;
      case "newimagelink":
        setState(() {
          newprov.changevalimg(1);
        });
        break;
      default:
      debugPrint("Unknown Command");
    }
  }

  @override
  void initState() {
    super.initState();
    Provider.of<ProviderGudang>(context,listen: false).changeVisual("Login");
  }

  @override
  Widget build(BuildContext context) {
  List account = Provider.of<ProviderGudang>(context).Gudang.user;
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 110),
              Icon(
                Icons.catching_pokemon,
                color: Colors.black,
                size: 120,
              ),
              SizedBox(height: 30),
              Text(
                "Login Account",
                style: TextStyle(
                  color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold
                ),
              ),
              SizedBox(height: 30),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 25),
                child: TextField(
                  controller: user,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.person,color: Colors.black,),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blue),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    fillColor: Colors.white,
                    filled: true,
                    labelText: "Username",
                    labelStyle: TextStyle(color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 25),
                child: TextField(
                  controller: pass,
                  obscureText: !isVisible,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.lock),
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          isVisible=!isVisible;
                        });
                      },
                      icon: isVisible ? Icon(Icons.visibility) : Icon(Icons.visibility_off),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blue),
                      borderRadius: BorderRadius.circular(15)
                    ),
                    fillColor: Colors.white,
                    filled: true,
                    labelText: "Password",
                    errorText: isCocok ? null : "Wrong Password",
                    labelStyle: TextStyle(color: Colors.grey[700]),
                  ),
                ),
              ),
              SizedBox(height: 30),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    int index = account[0].indexOf(user.text.toUpperCase());
                    if (index != -1) {
                      if (account[1][index] == pass.text) {
                        Provider.of<ProviderGudang>(context, listen: false).Gudang.usinguser = account[0][index];
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (context) => HomeView(
                              data: Provider.of<ProviderGudang>(context).Gudang,
                              fitur: listfitur,
                              user: Provider.of<ProviderGudang>(context).Gudang.usinguser
                            )
                          )
                        ).then((value) {
                          Provider.of<ProviderGudang>(context,listen: false).changeVisual("Login");
                        });
                        user.clear();
                        pass.clear();
                        Provider.of<ProviderGudang>(context, listen: false).sendUserInfo();
                      } else {
                        isCocok = false;
                        pass.clear();
                      }
                    } else {
                      isCocok = false;
                      pass.clear();
                    }
                  });
                }, 
                child: Text("Log In", style: TextStyle(fontSize: 15),),
                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.black,
                  elevation: 7,
                  fixedSize: Size.fromWidth(150),
                  padding:EdgeInsets.all(20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)
                  )
                ),
              ),
              SizedBox(height: 25),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Create New Account?"),
                  SizedBox(width: 4),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context,
                        MaterialPageRoute(builder: (context) => RegistrationView()),
                      );
                    },
                    child: Text(
                      "Register Now",
                      style: TextStyle(
                        color: Colors.blue,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}