import 'dart:convert';
import 'dart:io';

import 'package:alan_voice/alan_voice.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:AIII/component/data.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

final ImagePicker _picker = ImagePicker();
TextEditingController link = TextEditingController();
TextEditingController newstockname = TextEditingController();
TextEditingController brand = TextEditingController();
TextEditingController stock = TextEditingController();
class AddStock extends StatefulWidget {
  const AddStock({super.key});

  @override
  State<AddStock> createState() => _AddStockState();
}

class _AddStockState extends State<AddStock> {

  @override
  void initState() {
    super.initState();
    link.text = "";
    newstockname.text = "";
    brand.text = "";
    stock.text = "";
    Provider.of<NewProductImageModel>(context,listen: false).valstock = 1;
    Provider.of<NewProductImageModel>(context,listen: false).image = null;
    Provider.of<NewProductImageModel>(context,listen: false).valimg = 0;
    Provider.of<NewProductImageModel>(context,listen: false).showlinkimg = false;
    Provider.of<ProviderGudang>(context,listen: false).changeVisual("Add Product");
  }
  
  List<dynamic> newList(List<dynamic> inputList) {
    List hasil = [];
    inputList.forEach((subList) {
      hasil.add(subList[1]);
    });
    return hasil;
  }

  @override
  Widget build(BuildContext context) {
    NewProductImageModel prov = Provider.of<NewProductImageModel>(context,listen: false);
    XFile? newimage = Provider.of<NewProductImageModel>(context).image;
    int? valimg = Provider.of<NewProductImageModel>(context).valimg;
    bool? showlinkimg = Provider.of<NewProductImageModel>(context).showlinkimg;

    final Company data = Provider.of<ProviderGudang>(context).Gudang;
    return Scaffold(
      appBar: AppBar(
        foregroundColor: Colors.white,
        title: Text("Add Product", style: TextStyle(color: Colors.white),),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20),
          width: MediaQuery.of(context).size.width,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Add New Product", style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),)
                ]
              ),
              SizedBox(height: 20,),
              if(newimage != null)
              Center(
                child: Image(
                  image: FileImage(File(newimage!.path)),
                  height: 200,
                  width: 200,
                  fit: BoxFit.contain,
                ),
              )
              else if(showlinkimg)
              Center(
                child: Image(
                  image: NetworkImage(link.text),
                  height: 200,
                  width: 200,
                ),
              ),
              if(valimg == 1)
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      maxLines: null,
                      controller: link,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.black), 
                          borderRadius: BorderRadius.circular(15)
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.blue),
                          borderRadius: BorderRadius.circular(15)
                        ),
                        fillColor: Colors.white,
                        filled: true,
                        hintText: "Image URL",
                        hintStyle: TextStyle(fontSize: 16)
                      ),
                    ),
                  ),
                  SizedBox(width: 10,),
                  IconButton(
                    onPressed: () {
                      setState(() {
                        prov.changeshowlinkimg(true);
                        prov.updateimage(null);
                        sendsaveimg();
                      });
                    }, 
                    style: ButtonStyle(
                      backgroundColor: MaterialStatePropertyAll(Colors.green)
                    ),
                    icon: Icon(Icons.done,color: Colors.white,size: 35)
                  ),
                ]
              ),
              SizedBox(height: 15,),
              if(valimg==0 && newimage==null)
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                      showlinkimg = false;
                      valimg = 0;
                    });
                    showModalBottomSheet<void>(
                      isScrollControlled: true,
                      context: context,
                      builder: (context) => DraggableScrollableSheet(
                        expand: false,
                        initialChildSize: 0.6,
                        builder: (context, scrollController) => SingleChildScrollView(
                          controller: scrollController,
                          child: Center(
                            child: Container(
                              padding: EdgeInsets.all(20),
                              child: Column(
                                children: [
                                  Row(
                                    children: [Text("Product Image",style: TextStyle(fontSize: 15),)]
                                  ),
                                  SizedBox(height: 15,),
                                  ListTile(
                                    onTap:() async {
                                      Navigator.pop(context);
                                      prov.changevalimg(0);
                                      final XFile? image = await _picker.pickImage(source: ImageSource.camera);
                                      setState(() {
                                        if(image!=null){
                                          prov.updateimage(image);
                                          prov.changevalimg(0);
                                        }
                                      });
                                    },
                                    leading: Icon(Icons.camera_alt_outlined,size: 30,),
                                    title: Text('Capture from Camera',style: TextStyle(fontSize: 18),),
                                  ),
                                  ListTile(
                                    onTap:() async {
                                      Navigator.pop(context);
                                      prov.changevalimg(0);
                                      final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
                                      setState(() {
                                        if(image!=null){
                                          prov.updateimage(image);
                                          prov.changevalimg(0);
                                        }
                                      });
                                    },
                                    leading: Icon(Icons.photo_library_outlined,size: 30,),
                                    title: Text('Choose from Gallery',style: TextStyle(fontSize: 18),),
                                  ),
                                  ListTile(
                                    onTap:() {
                                      Navigator.pop(context);
                                      setState(() {
                                        prov.changevalimg(1);
                                      });
                                    },
                                    leading: Icon(Icons.link_outlined,size: 30,),
                                    title: Text('Input Link URL',style: TextStyle(fontSize: 18),),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    padding: valimg==0 && newimage==null ? EdgeInsets.all(30) : EdgeInsets.symmetric(horizontal: 20,vertical: 10),
                    backgroundColor: valimg==0 && newimage==null ? Colors.grey[300] : Colors.blue,
                    foregroundColor: Colors.grey[800],
                    shape: RoundedRectangleBorder(
                      borderRadius: valimg==0 && newimage==null && link.text == ""? BorderRadius.circular(15) : BorderRadius.circular(30)
                    ),
                    elevation: 5,
                  ),
                  child: 
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.add_photo_alternate_rounded,size: 60,),
                      Text("Add Image",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),)
                    ],
                  )
                ),
              ),
              SizedBox(height: 20,),
              Text("Product Name : ",style: TextStyle(fontSize: 18),),
              SizedBox(height: 10,),
              TextField(
                controller: newstockname,
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(15)
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue),
                    borderRadius: BorderRadius.circular(15)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Keyboard",
                  hintStyle: TextStyle(fontSize: 16)
                ),
              ),
              SizedBox(height: 20,),
              Text("Brand Name : ",style: TextStyle(fontSize: 18),),
              SizedBox(height: 10,),
              TextField(
                controller: brand,
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(15)
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue),
                    borderRadius: BorderRadius.circular(15)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Asus",
                  hintStyle: TextStyle(fontSize: 16)
                ),
              ),
              SizedBox(height: 15,),
              Text("Stock : ",style: TextStyle(fontSize: 18),),
              RadioListTile(
                contentPadding: EdgeInsets.symmetric(vertical: 3),
                value: 1, 
                groupValue: Provider.of<NewProductImageModel>(context).valstock, 
                onChanged: (value) {
                  setState(() {
                    Provider.of<NewProductImageModel>(context,listen: false).changevalstock(value);
                  });
                },
                title: Text("New Stock"),
                subtitle: Text("Default Stock : 0"),
              ),
              RadioListTile(
                contentPadding: EdgeInsets.symmetric(vertical: 3),
                value: 2, 
                groupValue: Provider.of<NewProductImageModel>(context).valstock, 
                onChanged: (value) {
                  setState(() {
                    Provider.of<NewProductImageModel>(context,listen: false).changevalstock(value);                  
                  });
                },
                title: Text("Old Stock"),
                subtitle: Text("You can change the default stock"),
              ),
              if (Provider.of<NewProductImageModel>(context,listen: false).valstock == 2 ) 
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 15),
                  child: TextField(
                    controller: stock,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.black),
                        borderRadius: BorderRadius.circular(15)
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue),
                        borderRadius: BorderRadius.circular(15)
                      ),
                      labelText: "Stock",
                    ),
                  ),
                ),
              SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      setState(() {
                        List item = valimg==0 
                        ? [prov.image, newstockname.text, brand.text, prov.valstock, prov.valstock==2 ? stock.text : 0] 
                        : [link.text, newstockname.text, brand.text, prov.valstock, stock.text];
                        Provider.of<ProviderGudang>(context,listen: false).addStock(context, item, prov.valimg);
                      });
                    }, 
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.all(15),
                      backgroundColor: Colors.green[500],
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)
                      )
                    ),
                    icon: Icon(Icons.save), 
                    label: Text("Save",style: TextStyle(fontSize: 17),)
                  ),
                  SizedBox(width: 15,),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.of(context).pop();
                    }, 
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.all(15),
                      backgroundColor: Colors.red[500],
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)
                      )
                    ),
                    icon: Icon(Icons.cancel), 
                    label: Text("Cancel",style: TextStyle(fontSize: 17),)
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}