import 'package:flutter/material.dart';
import 'package:AIII/AddTransactionPage.dart';
import 'package:AIII/component/cardtransaksi.dart';
import 'package:AIII/component/data.dart';
import 'package:provider/provider.dart';

List datapurchasing = [];

class PurchasingView extends StatefulWidget {
  PurchasingView({super.key});

  @override
  State<PurchasingView> createState() => _PurchasingViewState();
}

class _PurchasingViewState extends State<PurchasingView> {

  @override
  void initState() {
    super.initState();
    datapurchasing = Provider.of<ProviderGudang>(context,listen: false).Gudang.purchase;
    Provider.of<SearchModel>(context,listen: false).filterpurchasing = datapurchasing;
    Provider.of<SearchModel>(context,listen: false).searchpurchasing.text = "";
    Provider.of<ProviderGudang>(context,listen: false).changeVisual("Purchasing");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        title: Text("Purchasing", style: TextStyle(color: Colors.white),),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(7),
        color: Colors.grey,
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(5),
              child: TextField(
                controller: Provider.of<SearchModel>(context).searchpurchasing,
                onChanged: (value) {
                  setState(() {
                    List filtered=[];
                    if (value!=""){
                      for (int i = 0;i < datapurchasing.length; i++) {
                        if (datapurchasing[i][0].toLowerCase().contains(value.toLowerCase()) || datapurchasing[i][2].toLowerCase().contains(value.toLowerCase()) || datapurchasing[i][3].toLowerCase().contains(value.toLowerCase())) {
                          filtered.add(datapurchasing[i]);
                        }
                      }
                    }
                    else{
                      filtered = datapurchasing;
                    }
                    Provider.of<SearchModel>(context,listen: false).changepurchasing(filtered);
                  });
                },
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search,color: Colors.black),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Search",
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    ...Provider.of<SearchModel>(context).filterpurchasing.reversed.map<Widget>((item) {
                      return CardTrans(x: item, type:"Purchase");
                    }),
                  ],
                ),
              )
            )
          ]
        )
      ),
      floatingActionButton: ElevatedButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => AddTransaction(type: "",),)
          ).then((value) {
            Provider.of<ProviderGudang>(context,listen: false).changeVisual("Purchasing");
          });
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          elevation: 7,
          padding: EdgeInsets.all(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.add,size: 28,),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}