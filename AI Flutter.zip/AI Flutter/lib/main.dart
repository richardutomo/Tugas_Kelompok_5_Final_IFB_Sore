import 'package:AIII/StockPage.dart';
import 'package:flutter/material.dart';
import 'package:AIII/component/data.dart';
import 'package:AIII/loginpage.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => ProviderGudang(),),
        ChangeNotifierProvider(create: (context) => SearchModel(),),
        ChangeNotifierProvider(create: (context) => TransactionModel(),),
        ChangeNotifierProvider(create: (context) => ProductImageModel(),),
        ChangeNotifierProvider(create: (context) => NewProductImageModel(),)
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: LoginView(),
      ),
    );
  }
}