import 'package:flutter/material.dart';
import 'package:AIII/addstockpage.dart';
import 'package:AIII/component/cardstock.dart';
import 'package:AIII/component/data.dart';
import 'package:provider/provider.dart';

List datastock = [];

class StockView extends StatefulWidget {
  const StockView({super.key});

  @override
  State<StockView> createState() => _StockViewState();
}

class _StockViewState extends State<StockView> {

  @override
  void initState() {
    super.initState();
    datastock = Provider.of<ProviderGudang>(context,listen: false).Gudang.product;
    Provider.of<SearchModel>(context,listen: false).filter = datastock;
    Provider.of<SearchModel>(context,listen: false).search.text = "";
    Provider.of<ProviderGudang>(context,listen: false).changeVisual("Stock");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        title: Text("Stock", style: TextStyle(color: Colors.white),),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        padding: EdgeInsets.all(10),
        color: Colors.grey,
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.all(5),
              child: TextField(
                controller: Provider.of<SearchModel>(context).search,
                onChanged: (value) {
                  setState(() {
                    List filtered = [];
                    if (value!=""){
                      for (int i = 0;i < datastock.length; i++) {
                        if (datastock[i][1].toLowerCase().contains(value.toLowerCase()) || datastock[i][2].toLowerCase().contains(value.toLowerCase())) {
                          filtered.add(datastock[i]);
                        }
                      }
                    }
                    else{
                      filtered = datastock;
                    }
                    Provider.of<SearchModel>(context,listen: false).change(filtered);
                  });
                },
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search,color: Colors.black),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: "Search",
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    ...Provider.of<SearchModel>(context).search.text == ""
                    ? Provider.of<ProviderGudang>(context).Gudang.product.map<Widget>((item) {
                      return CardStock(produk: item);
                    })
                    : Provider.of<SearchModel>(context).filter.map<Widget>((item) {
                      return CardStock(produk: item);
                    }),
                  ],
                ),
              )
            )
          ]
        )
      ),
      floatingActionButton: ElevatedButton(
        onPressed: () {
          setState(() {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (context) => AddStock(),)
            ).then((value) {
              Provider.of<ProviderGudang>(context,listen: false).changeVisual("Stock");
            },);
          });
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          elevation: 7,
          padding: EdgeInsets.all(18),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.add,size: 28,),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}